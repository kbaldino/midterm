import java.util.Scanner;

public class passerRating 
{
	public static void main(String args[])
	{
		double TD;
		double YD;
		double INT;
		double COMP;
		double ATT;
	
	Scanner player = new Scanner(System.in);
	
	System.out.println("Please enter the number of touchdowns: ");
	TD = player.nextDouble();
	
	System.out.println("Please enter total yards rushed: ");
	YD = player.nextDouble();
	
	System.out.println("Please enter number of interceptions: ");
	INT = player.nextDouble();
	
	System.out.println("Please enter the number of completions: ");
	COMP = player.nextDouble();
	
	System.out.println("Please enter the number of passes attempted: ");
	ATT = player.nextDouble();
	
	double funA;
	funA = (COMP/ATT- 0.3)*5;
	
	double funB;
	funB = (YD/ATT - 3)*0.25;
	
	double funC;
	funC = (TD/ATT)*20;
	
	double funD;
	funD = 2.375 - (INT/ATT*25);
	
	double rating;
	rating = ((funA + funB + funC + funD)/6)*100;
	
	System.out.println("Your passer rating is " + rating);

	}
}
