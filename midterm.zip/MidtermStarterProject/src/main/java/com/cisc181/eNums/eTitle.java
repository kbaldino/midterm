package com.cisc181.eNums;

public enum eTitle {
LECTURER, PROFESSOR, DEAN
}
