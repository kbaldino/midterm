package com.cisc181.core;

import java.util.UUID;

public class Section {

	public UUID CourseID;
	public UUID SemesterID;
	public UUID SectionID;
	public int RoomID;
}
