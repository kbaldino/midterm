package com.cisc181.core;

import java.util.ArrayList;
import java.util.Date;

import com.cisc181.eNums.eTitle;

public class StaffTest extends Staff{

	public StaffTest(String FirstName, String MiddleName, String LastName, Date DOB, String Address,
			String Phone_number, String Email, String officeHours, int rank, double salary, Date hireDate,
			eTitle Title) {
		super(FirstName, MiddleName, LastName, DOB, Address, Phone_number, Email, officeHours, rank, salary, hireDate, Title);
		// TODO Auto-generated constructor stub

	}
}
