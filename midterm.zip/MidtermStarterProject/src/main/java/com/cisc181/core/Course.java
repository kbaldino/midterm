package com.cisc181.core;

import java.util.UUID;

public class Course {

	public UUID CourseID;
	public String CourseName;
	public int GradePoints;
	
}
